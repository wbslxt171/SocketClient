#!/system/bin/sh

while true; do
    # 获取当前时间（小时和分钟）
    current_hour=$(date +%H)
    current_minute=$(date +%M)
    current_second=$(date +%S)

    # 计算到下一个00:30的剩余时间（秒）
    if [ $current_hour -eq 0 ] && [ $current_minute -ge 30 ]; then
        # 如果当前时间已过00:30，等待到次日00:30
        wait_seconds=$(( (24*3600) - (current_hour*3600 + current_minute*60 + current_second) + (0*3600 + 30*60) ))
    else
        # 计算到今日00:30的剩余时间
        wait_seconds=$(( (0*3600 + 30*60) - (current_hour*3600 + current_minute*60 + current_second) ))
        if [ $wait_seconds -le 0 ]; then
            wait_seconds=$((wait_seconds + 24*3600))
        fi
    fi

    # 等待目标时间
    sleep $wait_seconds

    # 执行目标命令
    setprop persist.sys.stability.miui_fbo_enable true
done