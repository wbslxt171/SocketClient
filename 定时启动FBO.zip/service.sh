#!/system/bin/sh

# 后台运行检查脚本
nohup /data/adb/modules/hyper_fbo_setter/check_time.sh > /dev/null 2>&1 &